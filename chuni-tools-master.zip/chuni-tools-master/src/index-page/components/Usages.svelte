<script lang="ts">
    import { t } from "../store"
</script>

<h2>{$t("usages.title")}</h2>

<h3>{$t("usages.viewer.title")}</h3>
<p>{@html $t("usages.viewer.description")}</p>

<h3>{$t("usages.exportCsv.title")}</h3>
<p>{@html $t("usages.exportCsv.description")}</p>

<div />
