<script lang="ts">
    import { t } from "../store"
</script>

<h2>{@html $t("intro.title")}</h2>
<p>{@html $t("intro.about")}</p>
<p>{@html $t("intro.contact")}</p>
