import Root from "./components/Root.svelte"

const app = new Root({ target: document.body })

export default app