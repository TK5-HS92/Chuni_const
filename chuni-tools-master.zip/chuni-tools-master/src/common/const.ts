export const chuniNetBase = "chunithm-net-eng.com"
export const chuniNet = "https://" + chuniNetBase